import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const data=JSON.parse(await readFile(new URL('../content/manual.json',import.meta.url),'utf8'));
const ids=new Set(data.pages.map(p=>p.id));
const rules=new Set(data.rules.map(r=>r.id));
const sources=new Set(data.sources.map(s=>s.id));

test('All seven document parts and six workflows have traceable, usable content',()=>{
  assert.deepEqual(data.pages.filter(p=>p.kind==='part').map(p=>p.number),[1,2,3,4,5,6,7]);
  assert.equal(data.pages.filter(p=>p.kind==='flow').length,6);
  assert.equal(ids.size,data.pages.length);
  for(const p of data.pages){
    assert.ok(p.refs.length,p.id+' missing sources');
    for(const r of p.refs)assert.ok(sources.has(r.source_id),r.source_id);
    for(const r of p.rules)assert.ok(rules.has(r),r);
    for(const r of p.related)assert.ok(ids.has(r)||['regler','granska'].includes(r),r);
    if(p.kind==='flow'){
      assert.ok(p.sections.some(s=>s.kind==='steps'&&s.steps.length>=5),p.id);
      assert.ok(p.sections.some(s=>s.kind==='table'),p.id);
      assert.ok(p.sections.some(s=>s.title==='Vanliga fel'),p.id);
      assert.ok(p.sections.some(s=>s.kind==='example'),p.id+' missing a concrete example');
      assert.ok(p.checklist.length>=4,p.id);
    }
  }
});
test('All 62 rules retain scope, source, date, examples and truthful implementation status',()=>{
  assert.equal(data.rules.length,62);
  for(const r of data.rules){
    for(const key of ['description','document_type_and_scope','checked_on','control_type','correct_example','incorrect_example','status'])assert.ok(r[key],r.id+' '+key);
    assert.match(r.status,/lokala kontroller/);
    assert.match(r.status,/inte automatiskt verifierad/);
    assert.ok(r.source_refs.length);
    for(const ref of r.source_refs)assert.ok(sources.has(ref.source_id),r.id+' '+ref.source_id);
  }
});
test('Public bundle excludes local paths, internal links and identities from original cases',()=>{
  const text=JSON.stringify(data);
  for(const expression of [/C:\\/i,/intrapolis\./i,/sk-proj-/])assert.doesNotMatch(text,expression);
  for(const s of data.sources){assert.ok(!s.path&&!s.sha256);if(s.url)assert.match(s.url,/^https:\/\//);}
});
test('Legal and factual traps remain visible in manual content',()=>{
  const content=id=>JSON.stringify(data.pages.find(p=>p.id===id));
  assert.match(content('forhor'),/minimistraff minst sex månader/);
  assert.match(content('forhor'),/önskad offentlig försvarare är inte förordnad/);
  assert.match(content('portal-text'),/36 kap\. 12 § 1/);
  assert.match(content('portal-text'),/fyndet/);
  assert.match(content('tidslista'),/Insättning i cell/);
  assert.match(content('lob'),/inte en automatisk förlängning/);
  assert.match(content('lob'),/där hen eller någon annan har sin bostad/);
  assert.match(content('pl13'),/högst sex timmar/);
  assert.match(content('daf-text'),/inte verifierat/);
  assert.match(content('samkontroll'),/ingen|inte att webbplatsen/);
});
test('Templates preserve missing facts and do not assert standard formalities',()=>{
  const templates=data.pages.flatMap(p=>p.sections.filter(s=>s.kind==='template'));
  assert.equal(templates.length,12);
  for(const s of templates){assert.match(s.text,/\[/,s.title);assert.doesNotMatch(s.text,/uppläst utan erinran/i,s.title);}
});
test('Exercises have specific answers and source-backed feedback',()=>{
  for(const e of data.exercises){assert.ok(e.answer>=0&&e.answer<e.options.length);assert.ok(e.feedback.length>60);assert.ok(e.rules.every(r=>rules.has(r)));assert.match(e.lead,/fiktivt/);}
});
test('Build contains only static assets; no original PDFs or tracking or storage',async()=>{
  assert.deepEqual((await readdir(new URL('../dist/',import.meta.url))).sort(),['.nojekyll','app.js','data.js','index.html','release.json','review-engine.js','review-ui.js','style.css']);
  for(const file of ['app.js','review-ui.js','review-engine.js']){
    const app=await readFile(new URL('../src/'+file,import.meta.url),'utf8');
    assert.doesNotMatch(app,/localStorage|sessionStorage|indexedDB|\bfetch\s*\(|XMLHttpRequest|sendBeacon|document\.cookie/,file);
  }
  const html=await readFile(new URL('../dist/index.html',import.meta.url),'utf8');
  assert.match(html,/connect-src 'none'/);
  assert.match(html,/<html lang="sv">/);
  assert.doesNotMatch(html,/https?:\/\//);
  const built=await readFile(new URL('../dist/data.js',import.meta.url),'utf8');
  assert.deepEqual(JSON.parse(built.slice('window.MANUAL = '.length).trim().slice(0,-1)),data);
});

test('Release manifest identifies the exact current runtime files without local paths',async()=>{
  const release=JSON.parse(await readFile(new URL('../dist/release.json',import.meta.url),'utf8'));
  assert.equal(release.version,data.version);
  assert.ok(Number.isFinite(Date.parse(release.built_at)));
  assert.deepEqual(Object.keys(release.files).sort(),['.nojekyll','app.js','data.js','index.html','review-engine.js','review-ui.js','style.css']);
  for(const [name,sha256] of Object.entries(release.files)){
    const bytes=await readFile(new URL('../dist/'+name,import.meta.url));
    assert.equal(createHash('sha256').update(bytes).digest('hex'),sha256,name);
  }
  assert.doesNotMatch(JSON.stringify(release),/C:|file:\/\//i);
});
