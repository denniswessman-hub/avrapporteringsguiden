// Isolated code tests. These execute the real app.js with a small DOM interface
// stub; they do NOT verify browser layout, native clipboard/download permissions,
// accessibility behavior, or the print dialog.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {setImmediate as afterMicrotasks} from 'node:timers/promises';

const script=await readFile(new URL('../src/app.js',import.meta.url),'utf8');
const manual=JSON.parse(await readFile(new URL('../content/manual.json',import.meta.url),'utf8'));

function app({clipboardRejects=false}={}) {
  const elements=new Map(), events=new Map(), downloads=[], blobs=new Map();
  let copied, urlNumber=0, timerNumber=0;
  const focusNode={focus(){}};
  function element(id) {
    if(elements.has(id)) return elements.get(id);
    const listeners=new Map(), classes=new Set(), attrs=new Map();
    const node={
      innerHTML:'',outerHTML:'',textContent:'',value:'',dataset:{},checked:false,
      addEventListener(type,fn){listeners.set(type,fn);},
      emit(type,event={}){return listeners.get(type)?.({preventDefault(){},...event});},
      setAttribute(name,value){attrs.set(name,value);},
      focus(){},scrollIntoView(){},remove(){},select(){},
      querySelector(){return focusNode;},
      querySelectorAll(selector){return selector==='details'?node.details:[];},
      details:[],
      classList:{add(c){classes.add(c);},remove(c){classes.delete(c);},toggle(c){if(classes.has(c)){classes.delete(c);return false;}classes.add(c);return true;}}
    };
    elements.set(id,node);return node;
  }
  const main=element('#main');
  const document={
    title:'',activeElement:focusNode,
    querySelector:element,
    getElementById:id=>element('#'+id),
    body:{append(){}},
    createElement(tag){
      assert.equal(tag,'a','Unexpected DOM feature requested by the application');
      return {href:'',download:'',click(){downloads.push({name:this.download,blob:blobs.get(this.href)});},remove(){}};
    }
  };
  const location={hash:''};
  const win={MANUAL:manual,isSecureContext:true,scrollTo(){},print(){events.get('beforeprint')();events.get('afterprint')();}};
  const context=vm.createContext({
    window:win,document,location,Blob,
    navigator:{clipboard:{async writeText(text){if(clipboardRejects)throw new Error('clipboard permission denied');copied=text;}}},
    URL:{createObjectURL(blob){const key='blob:test-'+(++urlNumber);blobs.set(key,blob);return key;},revokeObjectURL(key){blobs.delete(key);}},
    addEventListener(type,fn){events.set(type,fn);},
    setTimeout(){return ++timerNumber;},clearTimeout(){}
  });
  vm.runInContext(script,context,{filename:'src/app.js'});
  function go(id){location.hash='#'+id;events.get('hashchange')();}
  function click(dataset={},attribute=null){
    const button={dataset,hasAttribute:name=>name===attribute};
    main.emit('click',{target:{closest:()=>button}});
  }
  function search(value){
    go('sok');element('#search').value=value;element('#search').emit('input');
    return element('#results').innerHTML;
  }
  return {element,main,go,click,search,downloads,events,location,copied:()=>copied,
    check(key,checked=true){main.emit('change',{target:{dataset:{check:key},checked}});},
    clear(){element('#clear-all').emit('click');}};
}

test('search finds Swedish text without diacritics, filters rules, and escapes query markup',()=>{
  const a=app();
  const hits=a.search('FORVAR');
  assert.match(hits,/class="search-result"/);
  assert.match(hits,/href="#tidslista"/);
  a.click({filter:'rule'});
  const filtered=a.element('#results').innerHTML;
  const links=[...filtered.matchAll(/href="([^"]+)"/g)].map(m=>m[1]);
  assert.ok(links.length>0);
  assert.ok(links.every(href=>href.startsWith('#regler/')));
  const query='<img src=x onerror="alert(1)"> &';
  const escaped=a.search(query);
  assert.match(escaped,/&lt;img src=x onerror=&quot;alert\(1\)&quot;&gt; &amp;/);
  assert.doesNotMatch(escaped,/<img/);
  assert.match(escaped,/Inga träffar/);
  assert.equal(a.location.hash,'#sok','Search text must not enter the URL');
});

test('copy passes the exact multiline template and gives an honest failure message',async()=>{
  const page=manual.pages.find(p=>p.id==='forhor');
  const index=page.sections.findIndex(s=>s.kind==='template');
  const key=`forhor:${index}`, expected=page.sections[index].text;
  const a=app();a.go('forhor');
  assert.ok(a.main.innerHTML.includes(`data-copy="${key}"`));
  a.click({copy:key});
  await afterMicrotasks();
  assert.equal(a.copied(),expected);
  assert.match(a.copied(),/\[K-nr\]/);
  assert.match(a.copied(),/\n\nFÖRSVARARE\n/);
  assert.equal(a.element('#notice').textContent,'Mallen är kopierad.');
  const denied=app({clipboardRejects:true});denied.go('forhor');denied.click({copy:key});
  await afterMicrotasks();
  assert.equal(denied.copied(),undefined);
  assert.match(denied.element('#notice').textContent,/Kopiering kunde inte genomföras/);
});

test('text export keeps Swedish UTF-8, source references, missing facts and checked state',async()=>{
  const a=app();a.go('tidslista');a.check('tidslista:0');a.click({},'data-export');
  assert.equal(a.downloads.length,1);
  const file=a.downloads[0], bytes=new Uint8Array(await file.blob.arrayBuffer());
  assert.equal(file.name,'tidslista.txt');
  assert.deepEqual([...bytes.slice(0,3)],[0xef,0xbb,0xbf]);
  const text=await file.blob.text();
  assert.match(text,/\[Tid saknas\] – Insättning i cell/);
  assert.match(text,/\[x\] Anmält-raden har rätt innebörd/);
  assert.match(text,/\[ \] Varje klockslag/);
  assert.match(text,/KÄLLSTÖD/);
  assert.match(text,/S10: Lathundar gripande, DAF samt tidslinje/);
  assert.doesNotMatch(text,/<(?:article|button|script)/);
  a.go('mallar');a.click({},'data-export');
  const all=await a.downloads[1].blob.text();
  for(const p of manual.pages) for(const s of p.sections) if(s.kind==='template')assert.ok(all.includes(s.text),s.title);
});

test('checklist and quiz state survives navigation, stays separate, and is fully cleared',()=>{
  const a=app();a.go('dur');a.check('dur:0');
  assert.equal(a.element('#check-count').textContent,'1 av 5 markerade');
  a.go('lob');assert.doesNotMatch(a.main.innerHTML,/data-check="lob:\d+" checked/);
  a.go('dur');assert.match(a.main.innerHTML,/data-check="dur:0" checked/);
  const exercise=manual.exercises[0];a.go('ovningar');a.click({answer:`${exercise.id}:${exercise.answer}`});
  assert.match(a.element('#ovning-'+exercise.id).outerHTML,/Rätt dokumentationsval/);
  a.go('start');a.go('ovningar');assert.match(a.main.innerHTML,/Rätt dokumentationsval/);
  a.search('förvar');a.clear();
  assert.equal(a.element('#search').value,'');
  assert.match(a.main.innerHTML,/Skriv ett sökord ovan/);
  a.go('dur');assert.doesNotMatch(a.main.innerHTML,/data-check="dur:\d+" checked/);
  a.go('ovningar');assert.doesNotMatch(a.main.innerHTML,/Rätt dokumentationsval|Det valet behöver ändras/);
  const fresh=app();fresh.go('dur');assert.doesNotMatch(fresh.main.innerHTML,/data-check="dur:\d+" checked/);
});

test('print preparation opens folded content and restores the original disclosure state',()=>{
  const a=app();a.go('dur');
  const closed={open:false}, alreadyOpen={open:true};a.main.details=[closed,alreadyOpen];
  a.events.get('beforeprint')();
  assert.equal(closed.open,true);assert.equal(alreadyOpen.open,true);
  a.events.get('afterprint')();
  assert.equal(closed.open,false);assert.equal(alreadyOpen.open,true);
});
