// Isolated execution of the real review UI and engine with a minimal DOM interface.
// These tests cover handlers, state, rendered HTML and output bytes. They do not
// establish browser layout, native permissions, accessibility, or visual quality.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';
import {setImmediate as afterMicrotasks} from 'node:timers/promises';

const engineSource=await readFile(new URL('../src/review-engine.js',import.meta.url),'utf8');
const uiSource=await readFile(new URL('../src/review-ui.js',import.meta.url),'utf8');
const appSource=await readFile(new URL('../src/app.js',import.meta.url),'utf8');
const manual=JSON.parse(await readFile(new URL('../content/manual.json',import.meta.url),'utf8'));
const unique=values=>[...new Set(values)];
const idsIn=(html,attribute)=>unique([...html.matchAll(new RegExp(`${attribute}="([^"]+)"`,'g'))].map(match=>match[1]));

function reviewer({clipboardRejects=false,secureContext=true,integrated=false}={}){
  const elements=new Map(),downloads=[],blobs=new Map(),announcements=[],clipboard=[];
  const globalEvents=new Map();
  let nextURL=0,focused='',selectedTextarea;
  const timers=[];
  let document;
  function element(selector){
    if(elements.has(selector))return elements.get(selector);
    const handlers=new Map(),classes=new Set(),attributes=new Map();
    const node={innerHTML:'',textContent:'',value:'',dataset:{},hidden:false,disabled:false,
      addEventListener(type,handler,{signal}={}){
        if(signal?.aborted)return;
        if(!handlers.has(type))handlers.set(type,new Set());
        handlers.get(type).add(handler);
        signal?.addEventListener('abort',()=>handlers.get(type).delete(handler),{once:true});
      },
      emit(type,event){for(const handler of [...(handlers.get(type)||[])])handler({preventDefault(){},...event});},
      querySelector:element,
      querySelectorAll(selector){return selector==='[data-fact-field="source"]'?[...elements.values()].filter(el=>el.dataset.factField==='source'):[];},
      focus(){focused=selector;document.activeElement=node;},
      setAttribute(name,value){attributes.set(name,value);},
      classList:{add(name){classes.add(name);},remove(name){classes.delete(name);},toggle(name){if(classes.has(name)){classes.delete(name);return false;}classes.add(name);return true;}},
      scrollIntoView(){},select(){selectedTextarea=node;},remove(){}
    };
    elements.set(selector,node);return node;
  }
  const host=element('#main');
  document={activeElement:element('#initial-focus'),body:{append(){}},
    title:'',querySelector:element,getElementById:id=>element('#'+id),
    createElement(tag){
      assert.ok(['a','textarea'].includes(tag),`Unexpected DOM operation ${tag}`);
      if(tag==='textarea')return {value:'',select(){selectedTextarea=this;},remove(){}};
      return {href:'',download:'',click(){downloads.push({name:this.download,blob:blobs.get(this.href)});},remove(){}};
    },
    execCommand(command){assert.equal(command,'copy');clipboard.push(selectedTextarea.value);return true;}
  };
  const forbidden=()=>{throw new Error('Unexpected network request or persistence');};
  const location={hash:integrated?'':'#granskare',search:''};
  const win={isSecureContext:secureContext,MANUAL:manual,scrollTo(){}};
  const context=vm.createContext({window:win,document,location,Blob,AbortController,
    navigator:{clipboard:{async writeText(value){if(clipboardRejects)throw new Error('Permission denied');clipboard.push(value);}},sendBeacon:forbidden},
    fetch:forbidden,XMLHttpRequest:forbidden,localStorage:{setItem:forbidden},sessionStorage:{setItem:forbidden},
    URL:{createObjectURL(blob){const id='blob:test-'+(++nextURL);blobs.set(id,blob);return id;},revokeObjectURL(id){blobs.delete(id);}},
    setTimeout(fn){timers.push(fn);return timers.length;},clearTimeout(){},
    addEventListener(type,handler){globalEvents.set(type,handler);}
  });
  vm.runInContext(engineSource,context,{filename:'src/review-engine.js',timeout:2000});
  vm.runInContext(uiSource,context,{filename:'src/review-ui.js',timeout:2000});
  const ui=win.ReviewUI;
  const mount=()=>{host.innerHTML=ui.render();ui.mount(host,{manual,onAnnounce:value=>announcements.push(value)});};
  if(integrated)vm.runInContext(appSource,context,{filename:'src/app.js',timeout:2000});
  else mount();
  function click(dataset={},attribute){const button={dataset,hasAttribute:name=>name===attribute};host.emit('click',{target:{closest:selector=>['button','button,a'].includes(selector)?button:null}});}
  function input(dataset,value,type='input'){
    const selector='input:'+JSON.stringify(dataset),target=element(selector);
    target.dataset=dataset;target.value=value;host.emit(type,{target});
  }
  return {host,element,downloads,clipboard,announcements,location,win,
    html:()=>ui.render(),click,input,
    text:(id,value)=>input({docId:id,docField:'text'},value),
    context:(key,value)=>input({context:key},value),
    run:()=>click({},'data-run-review'),
    unmount:()=>ui.unmount(),mount,
    go(id){location.hash='#'+id;globalEvents.get('hashchange')();},
    globalClear(){element('#clear-all').emit('click',{});},
    focus:()=>focused,
    async copied(id){click({copyResult:id});await afterMicrotasks();return clipboard.at(-1);},
    expireBlobs(){for(const fn of timers)fn();return blobs.size;}
  };
}

test('demo renders real review findings, conflicting evidence, source support and honest local scope',()=>{
  const app=reviewer();
  assert.match(app.html(),/Ingen AI-tjänst är ansluten/);
  assert.match(app.html(),/Texten stannar i webbläsaren/);
  app.click({},'data-demo');
  assert.match(app.host.innerHTML,/HELT FIKTIV ÖVNING/);
  app.run();
  const result=app.element('#review-results').innerHTML;
  assert.match(result,/Begränsad lokal granskning klar/);
  assert.match(result,/2 handlingar/);
  assert.match(result,/Olika uppgifter/);
  assert.match(result,/Övningstorget 1/);
  assert.match(result,/Övningstorget 2/);
  assert.match(result,/Källstöd och regel/);
  assert.match(result,/R31/);
  assert.match(result,/inte fullständigt verifierad/);
  assert.equal(app.focus(),'#review-result-heading');
  assert.match(app.element('#review-input-status').textContent,/granskningen är klar/);
});

test('accepting proposals in two documents changes only the selected document; reject, undo and reset restore originals',async()=>{
  const app=reviewer();
  const one='Första handlingens uppgift.  \nSlut.',two='Andra handlingens uppgift.  \nSlut.';
  app.text('doc-1',one);app.click({},'data-add-doc');app.text('doc-2',two);app.run();
  const proposalIds=idsIn(app.element('#review-results').innerHTML,'data-proposal');
  assert.equal(proposalIds.length,2);
  const [first,second]=proposalIds;
  assert.equal(await app.copied('doc-1'),one);
  assert.equal(await app.copied('doc-2'),two);
  app.click({proposal:first,choice:'accepted'});
  assert.equal(await app.copied('doc-1'),one.replace('  \n','\n'));
  assert.equal(await app.copied('doc-2'),two,'Another document must neither change nor fail to render');
  app.click({proposal:second,choice:'accepted'});
  assert.equal(await app.copied('doc-2'),two.replace('  \n','\n'));
  app.click({proposal:first,choice:'rejected'});
  assert.equal(await app.copied('doc-1'),one);
  assert.equal(await app.copied('doc-2'),two.replace('  \n','\n'));
  app.click({proposal:second,choice:'pending'});
  assert.equal(await app.copied('doc-2'),two);
  app.click({proposal:first,choice:'accepted'});app.click({proposal:second,choice:'accepted'});
  app.click({resetProposals:'doc-1'});
  assert.equal(await app.copied('doc-1'),one);
  assert.equal(await app.copied('doc-2'),two.replace('  \n','\n'));
  assert.match(app.element('#review-proposals').innerHTML,/Original · oförändrat/);
  assert.match(app.element('#review-proposals').innerHTML,/Borttaget/);
});

test('copy preserves exact Swedish text and reports failure honestly; local fallback also copies exact text',async()=>{
  const text='Åtgärd övervägdes.\nFörhörsplats: Övningsvägen 8.\nUppgift om skador saknas.';
  const app=reviewer();app.text('doc-1',text);app.run();
  assert.equal(await app.copied('doc-1'),text);
  assert.match(app.announcements.at(-1),/kopierad/);
  const denied=reviewer({clipboardRejects:true});denied.text('doc-1',text);denied.run();
  assert.equal(await denied.copied('doc-1'),undefined);
  assert.match(denied.announcements.at(-1),/Kopiering gick inte/);
  const fallback=reviewer({secureContext:false});fallback.text('doc-1',text);fallback.run();
  assert.equal(await fallback.copied('doc-1'),text);
});

test('document and full-review exports preserve UTF-8, exact originals, selected changes, dates and source context',async()=>{
  const app=reviewer();
  const originalCase='Övningscase: endast fiktiva uppgifter.\nÅtgärden övervägdes.';
  const first='Åtgärden övervägdes.  \nBrB 36 kap. 3 § 2.',second='En separat handling.  ';
  app.context('originalCase',originalCase);app.context('lawDate','2026-11-09');app.context('referenceDate','2026-11-08');
  app.text('doc-1',first);app.click({},'data-add-doc');app.text('doc-2',second);app.run();
  const firstProposal=idsIn(app.html(),'data-proposal')[0];app.click({proposal:firstProposal,choice:'accepted'});
  app.click({saveResult:'doc-1'});app.click({},'data-export-review');
  assert.equal(app.downloads.length,2);
  assert.equal(app.downloads[0].name,'bearbetad-doc-1.txt');
  assert.equal(app.downloads[1].name,'lokal-granskning.txt');
  for(const file of app.downloads){
    const bytes=new Uint8Array(await file.blob.arrayBuffer());
    assert.deepEqual([...bytes.slice(0,3)],[0xef,0xbb,0xbf]);
    assert.equal(file.blob.type,'text/plain;charset=utf-8');
  }
  assert.equal(await app.downloads[0].blob.text(),first.replace('  \n','\n'));
  const report=await app.downloads[1].blob.text();
  for(const value of [originalCase,first,second,first.replace('  \n','\n'),'2026-11-09','2026-11-08','BEGRÄNSNINGAR','R31','KÄLLSTÖD'])assert.ok(report.includes(value),value);
  assert.match(report,/inte.*verifierad|inte semantiskt/);
  assert.doesNotMatch(report,/<(?:article|button|details)/);
  assert.equal(app.location.hash,'#granskare');assert.equal(app.location.search,'');
  assert.equal(app.expireBlobs(),0,'Temporary download object URLs should be released');
});

test('new report input invalidates results and accepted changes until review is rerun',async()=>{
  const app=reviewer();app.text('doc-1','Tidigare text.  ');app.run();
  const proposal=idsIn(app.html(),'data-proposal')[0];app.click({proposal,choice:'accepted'});
  app.text('doc-1','Ny text.  ');
  assert.match(app.element('#review-results').innerHTML,/Underlaget har ändrats/);
  assert.doesNotMatch(app.html(),/Begränsad lokal granskning klar|Tidigare text/);
  app.click({},'data-export-review');assert.equal(app.downloads.length,0,'Invalidated results cannot be exported');
  app.run();
  assert.equal(await app.copied('doc-1'),'Ny text.  ','Old acceptance choices must not carry into a new review');
  assert.doesNotMatch(app.html(),/Tidigare text/);
});

test('case, dates, document type, basis and fact edits all invalidate prior results',()=>{
  const app=reviewer();app.text('doc-1','Underlag för kontroll.');
  app.click({},'data-add-fact');const factId=idsIn(app.html(),'data-fact-id')[0];
  const changes=[
    [{context:'originalCase'},'Ett nytt originalcase.'],
    [{context:'lawDate'},'2026-11-09'],
    [{context:'referenceDate'},'2026-11-08'],
    [{docId:'doc-1',docField:'type'},'daf_basis'],
    [{docId:'doc-1',basis:'law'},'13 § polislagen'],
    [{factId,factField:'value'},'14.25']
  ];
  for(const [dataset,value] of changes){
    app.run();assert.match(app.element('#review-results').innerHTML,/Begränsad lokal granskning klar/);
    app.input(dataset,value);
    assert.match(app.element('#review-results').innerHTML,/Underlaget har ändrats/);
  }
});

test('clear removes case, reports, factual comparisons, outcomes and acceptance choices',()=>{
  const app=reviewer();
  const marker='PRIVATE_CASE_d46bfa8';
  app.context('originalCase',marker);app.text('doc-1',marker+'  ');
  app.click({},'data-add-fact');const factId=idsIn(app.html(),'data-fact-id')[0];
  for(const [factField,value] of Object.entries({source:'case',key:'kNumber',value:marker,excerpt:marker}))app.input({factId,factField},value);
  app.run();const proposal=idsIn(app.html(),'data-proposal')[0];app.click({proposal,choice:'accepted'});
  app.click({},'data-clear-review');
  const clean=app.html();
  assert.doesNotMatch(clean,new RegExp(marker));
  assert.doesNotMatch(clean,/data-fact-id=|data-proposal=|Begränsad lokal granskning klar/);
  assert.equal(idsIn(clean,'data-doc').length,1);
  assert.equal(app.focus(),'#case-text');
  assert.match(app.announcements.at(-1),/rensade/);
  app.run();assert.match(app.element('#review-input-status').textContent,/Klistra in minst en egen text/);
  app.click({},'data-demo');assert.match(app.html(),/HELT FIKTIV ÖVNING/);
});

test('pasted HTML in case, report and comparison fields is escaped on every rendered surface',()=>{
  const app=reviewer();
  const markup='</textarea></pre><img src=x onerror="alert(1)"><script>alert(2)</script>&';
  app.context('originalCase',markup);app.text('doc-1',markup+'  ');
  app.click({},'data-add-fact');const factId=idsIn(app.html(),'data-fact-id')[0];
  for(const [factField,value] of Object.entries({source:'case',key:'findingPlace',subject:markup,event:markup,value:markup,excerpt:markup}))app.input({factId,factField},value);
  app.run();
  for(const html of [app.html(),app.element('#review-results').innerHTML]){
    assert.ok(html.includes('&lt;img src=x onerror=&quot;alert(1)&quot;&gt;'));
    assert.ok(html.includes('&lt;script&gt;alert(2)&lt;/script&gt;&amp;'));
    assert.doesNotMatch(html,/<img|<script|<svg/i);
  }
  app.click({reviewFilter:'language'});
  assert.doesNotMatch(app.element('#review-findings').innerHTML,/<img|<script|<svg/i);
  assert.equal(app.location.hash,'#granskare');assert.equal(app.location.search,'');
});

test('unmount/remount preserves in-memory drafts and results without duplicate event handlers or cross-session persistence',()=>{
  const app=reviewer();app.context('originalCase','Case i minnet.');app.text('doc-1','Text i minnet.  ');app.run();
  app.unmount();
  app.text('doc-1','Detta event ska ignoreras medan granskaren är avmonterad.');
  app.mount();
  assert.match(app.host.innerHTML,/Case i minnet/);
  assert.match(app.host.innerHTML,/Text i minnet/);
  assert.doesNotMatch(app.host.innerHTML,/Detta event ska ignoreras/);
  assert.match(app.host.innerHTML,/Begränsad lokal granskning klar/);
  app.click({},'data-add-doc');
  assert.equal(idsIn(app.html(),'data-doc').length,2,'One click must add exactly one document after remount');
  const separateVisit=reviewer();
  assert.doesNotMatch(separateVisit.html(),/Case i minnet|Text i minnet/);
});

test('demo refuses to overwrite a populated case and remove controls keep a concrete focus target',()=>{
  const app=reviewer();app.text('doc-1','Egen text som ska bevaras.');
  app.click({},'data-demo');
  assert.match(app.element('#review-input-status').textContent,/Rensa det nuvarande ärendet/);
  assert.match(app.html(),/Egen text som ska bevaras/);
  assert.doesNotMatch(app.html(),/HELT FIKTIV ÖVNING/);
  app.click({},'data-add-doc');app.click({removeDoc:'doc-2'});
  assert.equal(app.focus(),'[data-add-doc]');
  app.click({},'data-add-fact');const id=idsIn(app.html(),'data-fact-id')[0];app.click({removeFact:id});
  assert.equal(app.focus(),'[data-add-fact]');
  assert.doesNotMatch(app.html(),/data-fact-id=/);
});

test('separate DAF drafts are visible, copyable per document and exported without replacing either original',async()=>{
  const app=reviewer();
  const inputs=[
    {id:'doc-1',intervention:'pl13',law:'13 § polislagen',grounds:'störde den allmänna ordningen'},
    {id:'doc-2',intervention:'lob',law:'1 § LOB',grounds:'inte kunde ta hand om sig själv'}
  ];
  const originals=[];
  for(const [index,item] of inputs.entries()){
    if(index)app.click({},'data-add-doc');
    app.input({docId:item.id,docField:'type'},'daf_basis');
    app.input({docId:item.id,docField:'intervention'},item.intervention);
    const text=`Lagrum: ${item.law}. Omständighet: ${item.grounds}. `+
      'Patrullen dokumenterade åtgärderna och personens uppgifter i händelsebeskrivningen. '.repeat(8).trimEnd();
    originals.push(text);app.text(item.id,text);
    app.input({docId:item.id,basis:'law'},item.law);
    app.input({docId:item.id,basis:'grounds'},item.grounds);
  }
  app.run();
  assert.deepEqual(idsIn(app.element('#review-results').innerHTML,'data-copy-draft'),['doc-1','doc-2']);
  assert.match(app.element('#review-results').innerHTML,/Utkastet ersätter inte originalet eller händelsebeskrivningen/);
  const drafts=[];
  for(const [index,item] of inputs.entries()){
    app.click({copyDraft:item.id});await afterMicrotasks();
    const draft=app.clipboard.at(-1);drafts.push(draft);
    assert.ok(draft.includes(item.law)&&draft.includes(item.grounds));
    assert.ok(draft.length<originals[index].length/2);
    assert.equal(await app.copied(item.id),originals[index],'A copied short basis must not overwrite the full report');
  }
  assert.notEqual(drafts[0],drafts[1]);
  app.click({},'data-export-review');
  const report=await app.downloads[0].blob.text();
  assert.match(report,/SEPARATA GRUNDUTKAST – ERSÄTTER INTE ORIGINAL/);
  for(const text of [...originals,...drafts])assert.ok(report.includes(text));
});

test('the real application router mounts the reviewer, preserves drafts on manual navigation, and globally clears them',()=>{
  const app=reviewer({integrated:true});
  assert.match(app.host.innerHTML,/Från händelse till/);
  app.go('granska');assert.match(app.host.innerHTML,/Textgranskaren/);
  app.context('originalCase','ROUTER_CASE_768ca8');
  app.text('doc-1','ROUTER_DRAFT_768ca8  ');app.run();
  assert.match(app.element('#review-results').innerHTML,/Begränsad lokal granskning klar/);
  app.go('pm');
  assert.doesNotMatch(app.host.innerHTML,/ROUTER_CASE_768ca8|ROUTER_DRAFT_768ca8/);
  app.click({},'data-add-doc'); // The unmounted review handler must not see this event.
  app.go('granska');
  assert.match(app.host.innerHTML,/ROUTER_CASE_768ca8/);
  assert.match(app.host.innerHTML,/ROUTER_DRAFT_768ca8/);
  assert.match(app.host.innerHTML,/Begränsad lokal granskning klar/);
  assert.equal(idsIn(app.host.innerHTML,'data-doc').length,1);
  app.click({},'data-add-doc');
  assert.equal(idsIn(app.html(),'data-doc').length,2,'The router must not duplicate review listeners on return');
  app.go('lob');app.globalClear();app.go('granska');
  assert.doesNotMatch(app.host.innerHTML,/ROUTER_CASE_768ca8|ROUTER_DRAFT_768ca8|Begränsad lokal granskning klar/);
  assert.equal(idsIn(app.host.innerHTML,'data-doc').length,1);
  assert.match(app.element('#notice').textContent,/Alla inklistrade texter.*rensade/);
  app.run();assert.match(app.element('#review-input-status').textContent,/Klistra in minst en egen text/);
});
