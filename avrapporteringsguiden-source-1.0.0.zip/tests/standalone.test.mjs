import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {Script} from 'node:vm';
const html=await readFile(new URL('../output/Avrapporteringsguiden_1.0.0.html',import.meta.url),'utf8');
const scripts=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
const styles=[...html.matchAll(/<style>([\s\S]*?)<\/style>/g)].map(m=>m[1]);
const csp=html.match(/http-equiv="Content-Security-Policy" content="([^"]+)"/)[1];

test('Standalone manual contains complete scripts and styles, allowed by exact CSP hashes',()=>{
  assert.equal(scripts.length,4);
  assert.equal(styles.length,1);
  for(const code of [...scripts,...styles]){
    const hash=createHash('sha256').update(code).digest('base64');
    assert.ok(csp.includes(`'sha256-${hash}'`),'Inline content would be blocked');
  }
  for(const script of scripts)assert.doesNotThrow(()=>new Script(script));
  assert.ok(html.indexOf('<main id="main"')<html.indexOf('<script>'),'The app must run after the page structure exists');
  assert.doesNotMatch(html,/<script[^>]+src=|<link[^>]+rel="stylesheet"/);
  assert.match(csp,/connect-src 'none'/);
});

test('Standalone output is the current complete manual, without private local paths',async()=>{
  const source=JSON.parse(await readFile(new URL('../content/manual.json',import.meta.url),'utf8'));
  const embedded=JSON.parse(scripts[0].slice('window.MANUAL = '.length).trim().slice(0,-1));
  assert.deepEqual(embedded,source);
  assert.doesNotMatch(html,/C:\\\\Users|intrapolis\.|sk-proj-/);
  assert.match(html,/lang="sv"/);
});
