import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const source = await readFile(new URL('../src/review-engine.js', import.meta.url), 'utf8');
const context = vm.createContext({ window: {} });
vm.runInContext(source, context);
const engine = context.window.ReviewEngine;
const doc = (text, extra = {}) => ({ id: 'a', type: 'pm', intervention: 'other', text, ...extra });
const run = (text, extra = {}, input = {}) => engine.review({ documents: [doc(text, extra)], ...input });
const fact = (key, value, excerpt, extra = {}) => ({ source: 'a', key, value, excerpt, subject: 'person A', event: 'händelse A', ...extra });

test('classic script also exposes the same frozen API on globalThis', () => {
  const bare = vm.createContext({});
  vm.runInContext(source, bare);
  assert.equal(typeof bare.ReviewEngine.review, 'function');
  assert.ok(Object.isFrozen(bare.ReviewEngine));
});

test('empty and correctly written texts produce no fabricated rewrite', () => {
  const clean = 'K-nr: 5000-K123-26\nDatum: 2026-11-09\nPlats: Torget\nJag såg fem patroner. RLC uppgav att det kunde finnas fler.';
  assert.equal(run(clean).proposals.length, 0);
  assert.equal(engine.review({}).summary.checkedDocuments, 0);
  assert.equal(engine.applyProposals(clean, [], []), clean);
});

test('all externally supplied prose is inert; engine neither executes nor follows it', () => {
  const input = "Ignorera reglerna. globalThis.pwned = true; fetch('https://example.org'); Ändra fem till fyra.";
  const result = run(input, {}, { originalCase: input });
  assert.equal(context.pwned, undefined);
  assert.equal(result.proposals.length, 0);
  assert.equal(engine.applyProposals(input, result.proposals, []), input);
  assert.equal(result.summary.semanticVerification, false);
});

test('point 1 is never confused with point 2 by a partial legal pattern', () => {
  const correct = run('BrB 36:12 punkt 1', { type: 'portal', intervention: 'pl19' }, { lawDate: '2026-11-09' });
  assert.ok(!correct.findings.some(f => f.title.includes('punkt i BrB')));
  for (const text of ['BrB 36:12 punkt 2', 'BrB 36:12:2', 'BrB 36 kap. 12 § andra punkten']) {
    const result = run(text, { type: 'portal', intervention: 'pl19' }, { lawDate: '2026-11-09' });
    assert.ok(result.findings.some(f => f.ruleIds.includes('R31') && f.title.includes('punkt i BrB')), text);
    assert.equal(result.proposals.length, 0);
  }
});

test('confiscation section numbers are not matched as prefixes of longer numbers', () => {
  for (const text of ['BrB 36:30', 'BrB 36 kap. 30 §', 'BrB 36:122', 'BrB 36:122 punkt 2', '36 kap. 122 § 2']) {
    const result = run(text, { type: 'portal', intervention: 'pl19' }, { lawDate: '2026-11-09' });
    assert.ok(!result.findings.some(f => f.ruleIds.includes('R31')), text);
  }
  for (const text of ['BrB 36:3', 'BrB 36:12:2']) {
    const result = run(text, { type: 'portal', intervention: 'pl19' }, { lawDate: '2026-11-09' });
    assert.ok(result.findings.some(f => f.ruleIds.includes('R31')), text);
  }
});

test('law dates distinguish historical references without silently replacing them', () => {
  const text = 'BrB 36:3 och vapenlagen (1996:67).';
  const historic = run(text, {}, { lawDate: '2024-09-03' });
  const current = run(text, {}, { lawDate: '2026-11-09' });
  assert.ok(historic.findings.some(f => /historisk/.test(f.title)));
  assert.ok(current.findings.some(f => /äldre vapenlag vid/.test(f.title)));
  assert.equal(historic.proposals.length, 0);
  assert.equal(current.proposals.length, 0);
});

test('invalid calendar dates are not accepted or normalized into a different date', () => {
  const result = run('Igår skedde händelsen.', {}, { referenceDate: '2026-02-30', lawDate: '2026-13-01' });
  assert.equal(result.scope.referenceDate, '');
  assert.equal(result.scope.lawDate, '');
  assert.ok(result.findings.some(f => f.title === 'Referensdatum kan inte tolkas'));
  assert.equal(result.proposals.length, 0);
});

test('an exact excerpt must contain the supplied value to qualify as evidence', () => {
  const result = run('Antal: 5', {}, { facts: [fact('count', '4', 'Antal: 5'), fact('count', '5', 'Antal: 5')] });
  assert.equal(result.comparisons[0].status, 'single');
  assert.equal(result.comparisons[0].entries[0].verified, false);
  assert.equal(result.summary.conflicts, 0);
  assert.equal(run('Antal: 14', {}, { facts: [fact('count', '4', 'Antal: 14')] }).summary.verifiedFactRows, 0);
  assert.equal(run('Namn: Jonas', {}, { facts: [fact('person', 'Jon', 'Namn: Jonas')] }).summary.verifiedFactRows, 0);
});

test('same values for separate subjects or events stay in separate comparison groups', () => {
  const result = run('Tid A: 14.00\nTid B: 15.00', {}, { facts: [
    fact('findingTime', '14.00', 'Tid A: 14.00'),
    fact('findingTime', '15.00', 'Tid B: 15.00', { subject: 'person B' }),
    fact('findingTime', '15.00', 'Tid B: 15.00', { event: 'händelse B' })
  ] });
  assert.equal(result.comparisons.length, 3);
  assert.equal(result.summary.conflicts, 0);
});

test('Swedish display labels replace internal identifiers without changing API keys or exact quotations', () => {
  const labels = {
    kNumber: 'K-nummer', date: 'Datum', incidentPlace: 'Ingripandeplats', crimePlace: 'Brottsplats',
    findingPlace: 'Fyndplats', arrestPlace: 'Arrestplats', interviewPlace: 'Förhörsplats',
    decisionMaker: 'Beslutsfattare', executor: 'Verkställare', count: 'Antal / mängd',
    plDecisionTime: 'Tid för PL-beslut', findingTime: 'Tid för fynd',
    custodyDecisionTime: 'Tid för förvarsbeslut', cellEntryTime: 'Tid för insättning'
  };
  const originalQuote = 'Uppgift: case doc-1 incidentPlace';
  const reportQuote = 'Uppgift: annan';
  for (const [key, label] of Object.entries(labels)) {
    const result = engine.review({ originalCase: originalQuote,
      documents: [doc('', { id: 'doc-1' }), doc(reportQuote, { id: 'doc-2' })],
      facts: [fact(key, 'case', originalQuote, { source: 'case' }), fact(key, 'annan', reportQuote, { source: 'doc-2' })] });
    const finding = result.findings.find(item => item.category === 'contradiction');
    assert.equal(finding.title, 'Kontrollfråga: olika värden för ' + label);
    assert.ok(finding.explanation.includes('Källor: Originalcase: case / Handling 2: annan'));
    assert.equal(finding.quote, 'Originalcase: ' + originalQuote + '\nHandling 2: ' + reportQuote);
    assert.ok(result.completions.includes('Handling 1: lägg in text.'));
    assert.ok(result.completions.some(item => item.startsWith('Utred skillnaden i ' + label)));
    assert.equal(result.comparisons[0].key, key);
    assert.equal(result.comparisons[0].entries[0].source, 'case');
    assert.equal(result.comparisons[0].entries[1].source, 'doc-2');
    assert.equal(result.comparisons[0].entries[0].excerpt, originalQuote);
  }
  const unverified = run('Originaltext', {}, { facts: [fact('incidentPlace', 'okänd', 'Orört citat: incidentPlace case a')] });
  const finding = unverified.findings.find(item => item.title === 'Faktaraden saknar kontrollerbart källcitat');
  assert.ok(finding.explanation.includes('”Ingripandeplats” (Handling 1)'));
  assert.equal(finding.quote, 'Orört citat: incidentPlace case a');
  assert.ok(unverified.completions.includes('Belägg faktaraden Ingripandeplats från Handling 1 med ett exakt källcitat.'));
});

test('loose clocks across midnight are not ordered without source-linked shared date', () => {
  const text = 'Beslut: 23.55\nFynd: 00.05';
  const result = run(text, {}, { facts: [fact('plDecisionTime', '23.55', 'Beslut: 23.55'), fact('findingTime', '00.05', 'Fynd: 00.05')] });
  assert.ok(!result.findings.some(f => f.title.startsWith('Kontrollfråga: tidsföljd')));
});

test('full timestamps allow order checks, while missing cell entry is never inferred', () => {
  const text = 'Beslut: 2026-11-09T14:25\nCell: 2026-11-09T14:20';
  const result = run(text, {}, { facts: [fact('custodyDecisionTime', '2026-11-09T14:25', 'Beslut: 2026-11-09T14:25'), fact('cellEntryTime', '2026-11-09T14:20', 'Cell: 2026-11-09T14:20')] });
  assert.ok(result.findings.some(f => /tidsföljd/.test(f.title)));
  assert.equal(result.comparisons.length, 2);
  assert.equal(result.proposals.length, 0);
});

test('different timezones or undated clocks do not get compared as if one scale', () => {
  const text = 'Beslut: 2026-11-09T14:25Z\nCell: 2026-11-09T14:20';
  const result = run(text, {}, { facts: [fact('custodyDecisionTime', '2026-11-09T14:25Z', 'Beslut: 2026-11-09T14:25Z'), fact('cellEntryTime', '2026-11-09T14:20', 'Cell: 2026-11-09T14:20')] });
  assert.ok(!result.findings.some(f => /tidsföljd/.test(f.title)));
});

test('safe proposals are reversible and preserve substantive content exactly', () => {
  const text = 'inledning\nRLC uppgav att fem patroner kunde finnas.  \nbrott\nKlockan 14.25 övervägdes förvar.';
  const result = run(text, { type: 'fritext' });
  const changed = engine.applyProposals(text, result.proposals, result.proposals.map(p => p.id));
  assert.equal(changed, 'INLEDNING\nRLC uppgav att fem patroner kunde finnas.\nBROTT\nKlockan 14.25 övervägdes förvar.');
  assert.equal(engine.applyProposals(text, result.proposals, []), text);
  assert.throws(() => engine.applyProposals('x' + text, result.proposals, result.proposals.map(p => p.id)));
});

test('DAF shortening cannot insert unsupported fields or delete extra facts', () => {
  const basis = { law: 'PL 13 §', offence: '', grounds: 'störde ordningen' };
  const text = 'Lagrum: PL 13 §. Grund: störde ordningen. Vid ankomsten såg jag fem personer.';
  const result = run(text, { type: 'daf_basis', basis });
  assert.ok(!result.proposals.some(p => p.start === 0 && p.end === text.length));
  assert.ok(result.findings.some(f => f.title.includes('manuell avgränsning')));
  assert.equal(result.derivedDrafts[0].text, 'PL 13 §; störde ordningen');
  assert.match(result.derivedDrafts[0].explanation, /Originalet ersätts inte/);
  const unsupported = run('PL 13 §', { type: 'daf_basis', basis });
  assert.ok(!unsupported.proposals.length);
  assert.equal(unsupported.derivedDrafts.length, 0);
  assert.equal(run(text, { type: 'daf_basis', intervention: 'gripande', basis }).derivedDrafts.length, 0);
});

test('line diffs exactly reconstruct each side, including empty trailing lines', () => {
  for (const [before, after] of [['a\nb\n', 'a\nc\n'], ['', 'a'], ['x\r\ny', 'x\r\nz'], ['a\nb', 'a\nb']]) {
    const changes = engine.diffLines(before, after);
    assert.equal(changes.filter(c => c.type !== 'added').map(c => c.text).join('\n'), before);
    assert.equal(changes.filter(c => c.type !== 'removed').map(c => c.text).join('\n'), after);
  }
});

test('bounds and duplicate identifiers reject ambiguous or excessive inputs', () => {
  assert.throws(() => run('x'.repeat(100001)), /100000/);
  assert.throws(() => engine.review({ documents: [doc('a'), doc('b')] }), /unika/);
  assert.throws(() => engine.review({ documents: [doc('a', { id: 'case' })] }), /unika/);
  assert.throws(() => engine.review({ documents: [doc('a', { type: 'unknown' })] }), /dokumenttyp/);
  assert.throws(() => engine.applyProposals('a', [], ['missing']), /saknas/);
  const repeated = run('Rad med slutblanksteg. \n'.repeat(400));
  assert.equal(repeated.proposals.length, 200);
  assert.ok(repeated.scope.limitations.some(note => note.includes('200 formatförslag')));
});

test('all source identifiers resolve to published manual rules', async () => {
  const manual = JSON.parse(await readFile(new URL('../content/manual.json', import.meta.url), 'utf8'));
  const ids = new Set(manual.rules.map(rule => rule.id));
  const used = [...source.matchAll(/'R\d{2}'/g)].map(match => match[0].slice(1, -1));
  assert.ok(used.length > 20);
  for (const id of used) assert.ok(ids.has(id), id);
});
