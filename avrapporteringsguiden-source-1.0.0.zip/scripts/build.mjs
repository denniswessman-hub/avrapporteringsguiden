import {readFile, writeFile, mkdir, copyFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {createHash} from 'node:crypto';
const root = fileURLToPath(new URL('../', import.meta.url));
const data = JSON.parse(await readFile(path.join(root,'content/manual.json'),'utf8'));
await mkdir(path.join(root,'dist'),{recursive:true});
await writeFile(path.join(root,'dist/data.js'),`window.MANUAL = ${JSON.stringify(data).replace(/</g,'\\u003c')};\n`);
const scriptNames = ['data.js','review-engine.js','review-ui.js','app.js'];
for (const name of ['index.html','style.css',...scriptNames.slice(1)]) await copyFile(path.join(root,'src',name),path.join(root,'dist',name));
await writeFile(path.join(root,'dist/.nojekyll'),'');
const releaseFiles = ['index.html','style.css',...scriptNames,'.nojekyll'];
const fileHashes = {};
for (const name of releaseFiles) {
  fileHashes[name] = createHash('sha256').update(await readFile(path.join(root,'dist',name))).digest('hex');
}
await writeFile(path.join(root,'dist/release.json'), JSON.stringify({
  version: data.version,
  built_at: new Date().toISOString(),
  files: fileHashes
},null,2)+'\n');
const css = await readFile(path.join(root,'dist/style.css'),'utf8');
const scripts = await Promise.all(scriptNames.map(name => readFile(path.join(root,'dist',name),'utf8')));
const hash = value => `'sha256-${createHash('sha256').update(value).digest('base64')}'`;
let standalone = await readFile(path.join(root,'dist/index.html'),'utf8');
for (const name of scriptNames) standalone = standalone.replace(`  <script src="./${name}" defer></script>\n`,'');
standalone = standalone.replace('<link rel="stylesheet" href="./style.css">',`<style>${css}</style>`)
  .replace("script-src 'self'",`script-src ${scripts.map(hash).join(' ')}`)
  .replace("style-src 'self'",`style-src ${hash(css)}`)
  .replace('</body>',`${scripts.map(script=>`<script>${script}</script>`).join('\n')}\n</body>`);
await mkdir(path.join(root,'output'),{recursive:true});
await writeFile(path.join(root,`output/Avrapporteringsguiden_${data.version}.html`),standalone);
console.log(`Built ${data.pages.length} articles, ${data.rules.length} manual rules, version ${data.version}.`);
